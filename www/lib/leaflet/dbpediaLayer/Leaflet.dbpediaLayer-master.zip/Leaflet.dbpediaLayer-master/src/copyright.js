 /*
  Leaflet.dbpLayer a Leaflet plugin adding a markerGroup layer with dynamically loaded points of interest from DBpedia.
  (c) 2013, Christian Wörner
 */
